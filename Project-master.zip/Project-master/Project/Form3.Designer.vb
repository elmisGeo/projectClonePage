﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		Try
			If disposing AndAlso components IsNot Nothing Then
				components.Dispose()
			End If
		Finally
			MyBase.Dispose(disposing)
		End Try
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.TextBox1 = New System.Windows.Forms.TextBox()
		Me.Label1 = New System.Windows.Forms.Label()
		Me.TextBox2 = New System.Windows.Forms.TextBox()
		Me.Label2 = New System.Windows.Forms.Label()
		Me.TextBox3 = New System.Windows.Forms.TextBox()
		Me.Label3 = New System.Windows.Forms.Label()
		Me.ComboBox1 = New System.Windows.Forms.ComboBox()
		Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
		Me.DateTimePicker2 = New System.Windows.Forms.DateTimePicker()
		Me.Button1 = New System.Windows.Forms.Button()
		Me.GroupBox1 = New System.Windows.Forms.GroupBox()
		Me.Button4 = New System.Windows.Forms.Button()
		Me.Button3 = New System.Windows.Forms.Button()
		Me.Button2 = New System.Windows.Forms.Button()
		Me.Label4 = New System.Windows.Forms.Label()
		Me.Label5 = New System.Windows.Forms.Label()
		Me.Label6 = New System.Windows.Forms.Label()
		Me.TextBox4 = New System.Windows.Forms.TextBox()
		Me.Button5 = New System.Windows.Forms.Button()
		Me.Label7 = New System.Windows.Forms.Label()
		Me.DataGridView1 = New System.Windows.Forms.DataGridView()
		Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
		Me.MenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.AddProductGroupToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
		Me.Button6 = New System.Windows.Forms.Button()
		Me.GroupBox1.SuspendLayout()
		CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
		Me.MenuStrip1.SuspendLayout()
		Me.SuspendLayout()
		'
		'TextBox1
		'
		Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.TextBox1.Location = New System.Drawing.Point(152, 35)
		Me.TextBox1.Name = "TextBox1"
		Me.TextBox1.Size = New System.Drawing.Size(270, 26)
		Me.TextBox1.TabIndex = 1
		'
		'Label1
		'
		Me.Label1.AutoSize = True
		Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Label1.Location = New System.Drawing.Point(61, 38)
		Me.Label1.Name = "Label1"
		Me.Label1.Size = New System.Drawing.Size(85, 20)
		Me.Label1.TabIndex = 1
		Me.Label1.Text = "Product ID"
		'
		'TextBox2
		'
		Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.TextBox2.Location = New System.Drawing.Point(152, 77)
		Me.TextBox2.Name = "TextBox2"
		Me.TextBox2.Size = New System.Drawing.Size(270, 26)
		Me.TextBox2.TabIndex = 2
		'
		'Label2
		'
		Me.Label2.AutoSize = True
		Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Label2.Location = New System.Drawing.Point(36, 80)
		Me.Label2.Name = "Label2"
		Me.Label2.Size = New System.Drawing.Size(110, 20)
		Me.Label2.TabIndex = 3
		Me.Label2.Text = "Product Name"
		'
		'TextBox3
		'
		Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.TextBox3.Location = New System.Drawing.Point(152, 119)
		Me.TextBox3.Name = "TextBox3"
		Me.TextBox3.Size = New System.Drawing.Size(270, 26)
		Me.TextBox3.TabIndex = 4
		'
		'Label3
		'
		Me.Label3.AutoSize = True
		Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Label3.Location = New System.Drawing.Point(43, 122)
		Me.Label3.Name = "Label3"
		Me.Label3.Size = New System.Drawing.Size(103, 20)
		Me.Label3.TabIndex = 5
		Me.Label3.Text = "Product Price"
		'
		'ComboBox1
		'
		Me.ComboBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.ComboBox1.FormattingEnabled = True
		Me.ComboBox1.Location = New System.Drawing.Point(152, 161)
		Me.ComboBox1.Name = "ComboBox1"
		Me.ComboBox1.Size = New System.Drawing.Size(270, 28)
		Me.ComboBox1.TabIndex = 6
		'
		'DateTimePicker1
		'
		Me.DateTimePicker1.CustomFormat = "MM, dd, yy"
		Me.DateTimePicker1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.DateTimePicker1.Location = New System.Drawing.Point(152, 205)
		Me.DateTimePicker1.Name = "DateTimePicker1"
		Me.DateTimePicker1.Size = New System.Drawing.Size(270, 26)
		Me.DateTimePicker1.TabIndex = 7
		Me.DateTimePicker1.Value = New Date(2025, 2, 1, 6, 17, 0, 0)
		'
		'DateTimePicker2
		'
		Me.DateTimePicker2.CustomFormat = "MM, dd, yy"
		Me.DateTimePicker2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.DateTimePicker2.Location = New System.Drawing.Point(152, 247)
		Me.DateTimePicker2.Name = "DateTimePicker2"
		Me.DateTimePicker2.Size = New System.Drawing.Size(270, 26)
		Me.DateTimePicker2.TabIndex = 8
		Me.DateTimePicker2.Value = New Date(2025, 2, 1, 6, 17, 0, 0)
		'
		'Button1
		'
		Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Button1.Location = New System.Drawing.Point(17, 19)
		Me.Button1.Name = "Button1"
		Me.Button1.Size = New System.Drawing.Size(368, 30)
		Me.Button1.TabIndex = 9
		Me.Button1.Text = "Save"
		Me.Button1.UseVisualStyleBackColor = True
		'
		'GroupBox1
		'
		Me.GroupBox1.Controls.Add(Me.Button4)
		Me.GroupBox1.Controls.Add(Me.Button3)
		Me.GroupBox1.Controls.Add(Me.Button2)
		Me.GroupBox1.Controls.Add(Me.Button1)
		Me.GroupBox1.Location = New System.Drawing.Point(16, 288)
		Me.GroupBox1.Name = "GroupBox1"
		Me.GroupBox1.Size = New System.Drawing.Size(406, 169)
		Me.GroupBox1.TabIndex = 10
		Me.GroupBox1.TabStop = False
		Me.GroupBox1.Text = "Action Buttons"
		'
		'Button4
		'
		Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Button4.Location = New System.Drawing.Point(17, 127)
		Me.Button4.Name = "Button4"
		Me.Button4.Size = New System.Drawing.Size(368, 30)
		Me.Button4.TabIndex = 12
		Me.Button4.Text = "Report"
		Me.Button4.UseVisualStyleBackColor = True
		'
		'Button3
		'
		Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Button3.Location = New System.Drawing.Point(17, 91)
		Me.Button3.Name = "Button3"
		Me.Button3.Size = New System.Drawing.Size(368, 30)
		Me.Button3.TabIndex = 11
		Me.Button3.Text = "Delete"
		Me.Button3.UseVisualStyleBackColor = True
		'
		'Button2
		'
		Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Button2.Location = New System.Drawing.Point(17, 55)
		Me.Button2.Name = "Button2"
		Me.Button2.Size = New System.Drawing.Size(368, 30)
		Me.Button2.TabIndex = 10
		Me.Button2.Text = "Edit"
		Me.Button2.UseVisualStyleBackColor = True
		'
		'Label4
		'
		Me.Label4.AutoSize = True
		Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Label4.Location = New System.Drawing.Point(33, 164)
		Me.Label4.Name = "Label4"
		Me.Label4.Size = New System.Drawing.Size(113, 20)
		Me.Label4.TabIndex = 11
		Me.Label4.Text = "Product Group"
		'
		'Label5
		'
		Me.Label5.AutoSize = True
		Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Label5.Location = New System.Drawing.Point(19, 210)
		Me.Label5.Name = "Label5"
		Me.Label5.Size = New System.Drawing.Size(127, 20)
		Me.Label5.TabIndex = 12
		Me.Label5.Text = "Product Date Aq"
		'
		'Label6
		'
		Me.Label6.AutoSize = True
		Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Label6.Location = New System.Drawing.Point(12, 252)
		Me.Label6.Name = "Label6"
		Me.Label6.Size = New System.Drawing.Size(134, 20)
		Me.Label6.TabIndex = 13
		Me.Label6.Text = "Product Date Exp"
		'
		'TextBox4
		'
		Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.TextBox4.Location = New System.Drawing.Point(525, 396)
		Me.TextBox4.Name = "TextBox4"
		Me.TextBox4.Size = New System.Drawing.Size(508, 26)
		Me.TextBox4.TabIndex = 14
		'
		'Button5
		'
		Me.Button5.Location = New System.Drawing.Point(444, 396)
		Me.Button5.Name = "Button5"
		Me.Button5.Size = New System.Drawing.Size(75, 26)
		Me.Button5.TabIndex = 15
		Me.Button5.Text = "Search"
		Me.Button5.UseVisualStyleBackColor = True
		'
		'Label7
		'
		Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
		Me.Label7.Location = New System.Drawing.Point(444, 434)
		Me.Label7.Name = "Label7"
		Me.Label7.Size = New System.Drawing.Size(670, 23)
		Me.Label7.TabIndex = 16
		Me.Label7.Text = "Label7"
		Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
		'
		'DataGridView1
		'
		Me.DataGridView1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
		Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
		Me.DataGridView1.Location = New System.Drawing.Point(444, 35)
		Me.DataGridView1.Name = "DataGridView1"
		Me.DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
		Me.DataGridView1.Size = New System.Drawing.Size(670, 353)
		Me.DataGridView1.TabIndex = 17
		'
		'MenuStrip1
		'
		Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.MenuToolStripMenuItem})
		Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
		Me.MenuStrip1.Name = "MenuStrip1"
		Me.MenuStrip1.Size = New System.Drawing.Size(1138, 24)
		Me.MenuStrip1.TabIndex = 18
		Me.MenuStrip1.Text = "MenuStrip1"
		'
		'MenuToolStripMenuItem
		'
		Me.MenuToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddProductGroupToolStripMenuItem})
		Me.MenuToolStripMenuItem.Name = "MenuToolStripMenuItem"
		Me.MenuToolStripMenuItem.Size = New System.Drawing.Size(50, 20)
		Me.MenuToolStripMenuItem.Text = "Menu"
		'
		'AddProductGroupToolStripMenuItem
		'
		Me.AddProductGroupToolStripMenuItem.Name = "AddProductGroupToolStripMenuItem"
		Me.AddProductGroupToolStripMenuItem.Size = New System.Drawing.Size(177, 22)
		Me.AddProductGroupToolStripMenuItem.Text = "Add Product Group"
		'
		'Button6
		'
		Me.Button6.Location = New System.Drawing.Point(1039, 397)
		Me.Button6.Name = "Button6"
		Me.Button6.Size = New System.Drawing.Size(75, 26)
		Me.Button6.TabIndex = 19
		Me.Button6.Text = "Clear "
		Me.Button6.UseVisualStyleBackColor = True
		'
		'Form3
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(1138, 473)
		Me.Controls.Add(Me.Button6)
		Me.Controls.Add(Me.DataGridView1)
		Me.Controls.Add(Me.Label7)
		Me.Controls.Add(Me.Button5)
		Me.Controls.Add(Me.TextBox4)
		Me.Controls.Add(Me.Label6)
		Me.Controls.Add(Me.Label5)
		Me.Controls.Add(Me.Label4)
		Me.Controls.Add(Me.GroupBox1)
		Me.Controls.Add(Me.DateTimePicker2)
		Me.Controls.Add(Me.DateTimePicker1)
		Me.Controls.Add(Me.ComboBox1)
		Me.Controls.Add(Me.TextBox3)
		Me.Controls.Add(Me.Label3)
		Me.Controls.Add(Me.TextBox2)
		Me.Controls.Add(Me.Label2)
		Me.Controls.Add(Me.TextBox1)
		Me.Controls.Add(Me.Label1)
		Me.Controls.Add(Me.MenuStrip1)
		Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
		Me.MainMenuStrip = Me.MenuStrip1
		Me.MaximizeBox = False
		Me.Name = "Form3"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Add Product"
		Me.GroupBox1.ResumeLayout(False)
		CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
		Me.MenuStrip1.ResumeLayout(False)
		Me.MenuStrip1.PerformLayout()
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub

	Friend WithEvents TextBox1 As TextBox
	Friend WithEvents Label1 As Label
	Friend WithEvents TextBox2 As TextBox
	Friend WithEvents Label2 As Label
	Friend WithEvents TextBox3 As TextBox
	Friend WithEvents Label3 As Label
	Friend WithEvents ComboBox1 As ComboBox
	Friend WithEvents DateTimePicker1 As DateTimePicker
	Friend WithEvents DateTimePicker2 As DateTimePicker
	Friend WithEvents Button1 As Button
	Friend WithEvents GroupBox1 As GroupBox
	Friend WithEvents Button4 As Button
	Friend WithEvents Button3 As Button
	Friend WithEvents Button2 As Button
	Friend WithEvents Label4 As Label
	Friend WithEvents Label5 As Label
	Friend WithEvents Label6 As Label
	Friend WithEvents TextBox4 As TextBox
	Friend WithEvents Button5 As Button
	Friend WithEvents Label7 As Label
	Friend WithEvents DataGridView1 As DataGridView
	Friend WithEvents MenuStrip1 As MenuStrip
	Friend WithEvents MenuToolStripMenuItem As ToolStripMenuItem
	Friend WithEvents AddProductGroupToolStripMenuItem As ToolStripMenuItem
	Friend WithEvents Button6 As Button
End Class
